modded class MissionServer
{
    override void OnInit()
    {
        super.OnInit();

        PredAI_Debug.Enabled = true;
        PredAI_Debug.Log("Pred Ai V2 loaded.");
        PredAI_Debug.Log("This confirms the PBO is a real mounted DayZ addon.");
        PredAI_Director.Get();
    }

    override void OnUpdate(float timeslice)
    {
        super.OnUpdate(timeslice);

        if (!GetGame() || !GetGame().IsServer())
            return;

        PredAI_Director.Get().Think();
    }
}
