class PredAI_MemoryEvent
{
    string TypeName;
    vector Position;
    float TimeSeconds;
    float Weight;
    string Note;

    void PredAI_MemoryEvent(string typeName = "", vector position = "0 0 0", float weight = 1.0, string note = "")
    {
        TypeName = typeName;
        Position = position;
        Weight = weight;
        Note = note;
        TimeSeconds = GetGame().GetTime() * 0.001;
    }
}

class PredAI_MemoryBank
{
    ref array<ref PredAI_MemoryEvent> Events;

    void PredAI_MemoryBank()
    {
        Events = new array<ref PredAI_MemoryEvent>;
    }

    void Remember(string typeName, vector position, float weight, string note = "")
    {
        Events.Insert(new PredAI_MemoryEvent(typeName, position, weight, note));
        PredAI_Debug.Log("Memory: " + typeName + " pos=" + position.ToString() + " note=" + note);
    }

    vector GetRecentPosition(string typeName, float maxAgeSeconds)
    {
        float nowSeconds = GetGame().GetTime() * 0.001;
        float bestScore = -1.0;
        vector bestPos = "0 0 0";

        foreach (PredAI_MemoryEvent eventData : Events)
        {
            if (!eventData)
                continue;

            if (eventData.TypeName != typeName)
                continue;

            float age = nowSeconds - eventData.TimeSeconds;
            if (age > maxAgeSeconds)
                continue;

            float score = eventData.Weight / Math.Max(age, 1.0);
            if (score > bestScore)
            {
                bestScore = score;
                bestPos = eventData.Position;
            }
        }

        return bestPos;
    }

    int Count()
    {
        return Events.Count();
    }
}
