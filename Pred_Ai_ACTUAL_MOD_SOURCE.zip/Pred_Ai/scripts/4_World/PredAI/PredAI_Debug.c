class PredAI_Debug
{
    static bool Enabled = true;

    static void Log(string message)
    {
        if (!Enabled)
            return;

        Print("[Pred Ai V2] " + message);
    }
}
