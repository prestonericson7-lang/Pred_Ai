class PredAI_Director
{
    static ref PredAI_Director s_Instance;

    ref PredAI_MemoryBank GlobalMemory;
    ref PredAI_Personality ServerPersonality;
    int LastThinkTime;

    void PredAI_Director()
    {
        GlobalMemory = new PredAI_MemoryBank;
        ServerPersonality = new PredAI_Personality;
        LastThinkTime = 0;

        PredAI_Debug.Log("Director created. Personality: " + ServerPersonality.ToDebugString());
    }

    static PredAI_Director Get()
    {
        if (!s_Instance)
            s_Instance = new PredAI_Director;

        return s_Instance;
    }

    void RegisterGunshot(vector position)
    {
        GlobalMemory.Remember("gunshot", position, 1.0, "combat noise");
    }

    void RegisterExplosion(vector position)
    {
        GlobalMemory.Remember("explosion", position, 1.35, "high value combat noise");
    }

    void RegisterAIDeath(vector position)
    {
        GlobalMemory.Remember("ai_death", position, 1.20, "AI died here");
    }

    void Think()
    {
        int now = GetGame().GetTime();

        if (now - LastThinkTime < 20000)
            return;

        LastThinkTime = now;

        PredAI_Goal goal = PredAI_GoalSystem.PickGoal(ServerPersonality, GlobalMemory, 1.0);
        PredAI_Debug.Log("Director think goal=" + PredAI_GoalSystem.GoalToString(goal) + " memoryEvents=" + GlobalMemory.Count().ToString());
    }
}
