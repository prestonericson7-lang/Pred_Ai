class PredAI_Personality
{
    float Aggression;
    float Confidence;
    float Stealth;
    float Patience;
    float SelfPreservation;
    float Curiosity;
    float AmbushPreference;
    float VehicleDesire;
    float SocialTolerance;

    void PredAI_Personality()
    {
        Randomize();
    }

    void Randomize()
    {
        Aggression = Math.RandomFloatInclusive(0.25, 1.0);
        Confidence = Math.RandomFloatInclusive(0.20, 1.0);
        Stealth = Math.RandomFloatInclusive(0.20, 1.0);
        Patience = Math.RandomFloatInclusive(0.20, 1.0);
        SelfPreservation = Math.RandomFloatInclusive(0.25, 1.0);
        Curiosity = Math.RandomFloatInclusive(0.20, 1.0);
        AmbushPreference = Math.RandomFloatInclusive(0.20, 1.0);
        VehicleDesire = Math.RandomFloatInclusive(0.20, 1.0);
        SocialTolerance = Math.RandomFloatInclusive(0.0, 0.75);
    }

    string ToDebugString()
    {
        return "agg=" + Aggression.ToString() + " conf=" + Confidence.ToString() + " stealth=" + Stealth.ToString() + " preserve=" + SelfPreservation.ToString();
    }
}
