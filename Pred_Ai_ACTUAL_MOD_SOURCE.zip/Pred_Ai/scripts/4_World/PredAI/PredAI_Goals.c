enum PredAI_Goal
{
    SURVIVE = 0,
    INVESTIGATE_GUNFIRE,
    SHADOW_PLAYER,
    AMBUSH_PLAYER,
    RETREAT_AND_HEAL,
    ACQUIRE_SUPPLIES,
    SEEK_VEHICLE,
    ROAD_AMBUSH,
    HOLD_TERRITORY
}

class PredAI_GoalSystem
{
    static PredAI_Goal PickGoal(PredAI_Personality personality, PredAI_MemoryBank memory, float health01)
    {
        if (!personality || !memory)
            return PredAI_Goal.SURVIVE;

        if (health01 < 0.35 && personality.SelfPreservation > 0.45)
            return PredAI_Goal.RETREAT_AND_HEAL;

        vector gunPos = memory.GetRecentPosition("gunshot", 1080.0);
        if (gunPos != vector.Zero)
        {
            if (personality.Stealth + personality.Patience + personality.AmbushPreference > 1.55)
                return PredAI_Goal.SHADOW_PLAYER;

            if (personality.Aggression + personality.Confidence + personality.Curiosity > 1.35)
                return PredAI_Goal.INVESTIGATE_GUNFIRE;
        }

        if (personality.VehicleDesire > 0.80)
            return PredAI_Goal.SEEK_VEHICLE;

        if (personality.AmbushPreference > 0.75)
            return PredAI_Goal.ROAD_AMBUSH;

        if (personality.Aggression > 0.70)
            return PredAI_Goal.SHADOW_PLAYER;

        return PredAI_Goal.HOLD_TERRITORY;
    }

    static string GoalToString(PredAI_Goal goal)
    {
        if (goal == PredAI_Goal.INVESTIGATE_GUNFIRE) return "InvestigateGunfire";
        if (goal == PredAI_Goal.SHADOW_PLAYER) return "ShadowPlayer";
        if (goal == PredAI_Goal.AMBUSH_PLAYER) return "AmbushPlayer";
        if (goal == PredAI_Goal.RETREAT_AND_HEAL) return "RetreatAndHeal";
        if (goal == PredAI_Goal.ACQUIRE_SUPPLIES) return "AcquireSupplies";
        if (goal == PredAI_Goal.SEEK_VEHICLE) return "SeekVehicle";
        if (goal == PredAI_Goal.ROAD_AMBUSH) return "RoadAmbush";
        if (goal == PredAI_Goal.HOLD_TERRITORY) return "HoldTerritory";
        return "Survive";
    }
}
