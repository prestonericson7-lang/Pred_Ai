class PredAI_Social
{
    static float EvaluateText(string text, PredAI_Personality personality)
    {
        if (!personality)
            return 0.0;

        text.ToLower();
        float score = 0.0;

        if (text.Contains("friendly") || text.Contains("dont shoot") || text.Contains("don't shoot") || text.Contains("surrender"))
            score += 0.45 + personality.SocialTolerance * 0.35;

        if (text.Contains("trade") || text.Contains("food") || text.Contains("ammo") || text.Contains("help"))
            score += 0.20;

        if (text.Contains("kill you") || text.Contains("you're dead") || text.Contains("your dead"))
            score -= 0.55;

        return Math.Clamp(score, -1.0, 1.0);
    }
}
