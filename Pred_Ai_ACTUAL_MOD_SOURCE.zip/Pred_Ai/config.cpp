class CfgPatches
{
    class Pred_Ai
    {
        units[] = {};
        weapons[] = {};
        requiredVersion = 0.1;
        requiredAddons[] =
        {
            "DZ_Data",
            "DayZExpansion_AI"
        };
    };
};

class CfgMods
{
    class Pred_Ai
    {
        dir = "Pred_Ai";
        name = "Pred Ai";
        type = "mod";
        dependencies[] =
        {
            "World",
            "Mission"
        };

        class defs
        {
            class worldScriptModule
            {
                value = "";
                files[] =
                {
                    "Pred_Ai/scripts/4_World"
                };
            };

            class missionScriptModule
            {
                value = "";
                files[] =
                {
                    "Pred_Ai/scripts/5_Mission"
                };
            };
        };
    };
};
