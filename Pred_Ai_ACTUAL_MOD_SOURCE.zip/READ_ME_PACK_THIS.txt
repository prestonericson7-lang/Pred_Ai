This zip contains the ACTUAL MOD SOURCE, not just empty folders.

The folder to give to DayZ Tools Addon Builder is:

Pred_Ai

That folder contains:
- config.cpp
- scripts/4_World/PredAI/*.c
- scripts/5_Mission/PredAI/*.c

Addon Builder output name:
Pred_Ai.pbo

After packing:
- Put Pred_Ai.pbo into SERVER_UPLOAD_AFTER_PACKING/Pred_Ai/addons
- Sign it
- Put the .bisign beside it
- Put your .bikey in SERVER_UPLOAD_AFTER_PACKING/Pred_Ai/keys and the server root keys folder
- Upload SERVER_UPLOAD_AFTER_PACKING/Pred_Ai to HostHavoc
- Commandline uses ;Pred_Ai

When it works, server logs show:
[Pred Ai V2] Pred Ai V2 loaded.
