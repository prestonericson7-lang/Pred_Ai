Pack the TOP LEVEL folder named Pred_Ai from this zip with Addon Builder. Put Pred_Ai.pbo and its .bisign here.
