protocol = 1;
publishedid = 0;
name = "Pred Ai";
timestamp = 0;
