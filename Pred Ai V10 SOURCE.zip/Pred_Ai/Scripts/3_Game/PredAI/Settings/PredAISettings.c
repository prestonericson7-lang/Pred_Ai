class PredAISettings
{
    int version;
    bool enabled;
    bool debug;
    bool debug_score;
    bool debug_goal;
    float tick_seconds;
    float score_eval_seconds;
    float brain_decision_cooldown;

    ref PredAIMedicalSettings medical;
    ref PredAICombatSettings combat;
    ref PredAINavigationSettings navigation;
    ref PredAILootSettings loot;
    ref PredAIWeaponSettings weapon;
    ref PredAIScoreSettings scoring;
    ref PredAIPersonalitySettings personality;

    void PredAISettings()
    {
        version = 9;
        enabled = true;
        debug = false;
        debug_score = false;
        debug_goal = true;
        tick_seconds = 0.15;
        score_eval_seconds = 0.75;
        brain_decision_cooldown = 0.35;

        medical = new PredAIMedicalSettings();
        combat = new PredAICombatSettings();
        navigation = new PredAINavigationSettings();
        loot = new PredAILootSettings();
        weapon = new PredAIWeaponSettings();
        scoring = new PredAIScoreSettings();
        personality = new PredAIPersonalitySettings();
    }

    void EnsureDefaults()
    {
        if (!medical) medical = new PredAIMedicalSettings();
        if (!combat) combat = new PredAICombatSettings();
        if (!navigation) navigation = new PredAINavigationSettings();
        if (!loot) loot = new PredAILootSettings();
        if (!weapon) weapon = new PredAIWeaponSettings();
        if (!scoring) scoring = new PredAIScoreSettings();
        if (!personality) personality = new PredAIPersonalitySettings();

        if (version < 9) version = 9;
        if (tick_seconds <= 0.0) tick_seconds = 0.15;
        if (score_eval_seconds <= 0.0) score_eval_seconds = 0.75;
        if (brain_decision_cooldown <= 0.0) brain_decision_cooldown = 0.35;
        if (navigation.move_threshold_meters <= 0.0) navigation.move_threshold_meters = 0.35;
        if (navigation.repath_seconds <= 0.0) navigation.repath_seconds = 1.15;
        if (navigation.idle_repath_seconds <= 0.0) navigation.idle_repath_seconds = 4.25;
        if (loot.scan_radius <= 0.0) loot.scan_radius = 60.0;
        if (loot.pickup_distance <= 0.0) loot.pickup_distance = 2.85;
        if (loot.max_objects_per_scan <= 0) loot.max_objects_per_scan = 112;
        if (loot.scan_cooldown <= 0.0) loot.scan_cooldown = 0.85;
        if (combat.direct_fire_cooldown <= 0.0) combat.direct_fire_cooldown = 0.45;
        if (weapon.setup_cooldown <= 0.0) weapon.setup_cooldown = 0.70;
    }
}
