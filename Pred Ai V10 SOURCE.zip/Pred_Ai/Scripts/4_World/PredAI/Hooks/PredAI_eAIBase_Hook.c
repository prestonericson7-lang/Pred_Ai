modded class eAIBase
{
    override void Init()
    {
        super.Init();

        if (g_Game && g_Game.IsServer())
            PredAI_Runtime.Register(this);
    }

    override void eAI_OnUpdate(float pDt)
    {
        super.eAI_OnUpdate(pDt);

        if (g_Game && g_Game.IsServer())
            PredAI_Runtime.Tick(this, pDt);
    }

    override void EEHitBy(TotalDamageResult damageResult, int damageType, EntityAI source, int component, string dmgZone, string ammo, vector modelPos, float speedCoef)
    {
        super.EEHitBy(damageResult, damageType, source, component, dmgZone, ammo, modelPos, speedCoef);

        if (g_Game && g_Game.IsServer())
            PredAI_Runtime.OnHit(this, source);
    }

    override void EEKilled(Object killer)
    {
        super.EEKilled(killer);

        if (g_Game && g_Game.IsServer())
            PredAI_Runtime.OnKilled(this, killer);
    }

    //! eAI_OnInventoryEnter: called by Expansion AI when AI picks up an item
    override void eAI_OnInventoryEnter(ItemBase item)
    {
        super.eAI_OnInventoryEnter(item);

        if (g_Game && g_Game.IsServer())
            PredAI_Runtime.OnInventoryEnter(this, item);
    }
}
