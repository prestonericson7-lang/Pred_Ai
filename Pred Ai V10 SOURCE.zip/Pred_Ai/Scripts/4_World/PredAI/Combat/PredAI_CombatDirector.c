class PredAI_CombatDirector
{
    static void Execute(PredAI_Context ctx, float dt)
    {
        if (!ctx || !ctx.ai || !ctx.has_target)
            return;

        eAIBase ai = ctx.ai;

        //! GetTarget(0) = primary target from Expansion AI targeting list
        eAITarget target = null;
        if (ai.TargetCount() > 0)
            target = ai.GetTarget(0);
        if (!target)
            return;

        PredAISettings cfg = PredAI_Config.Get();
        float dist = target.GetDistance();

        //! Try to get a loaded, ready weapon
        Weapon_Base gun = ai.eAI_GetAnyWeaponToUse(true, false);

        //! No ready gun but we have ammo pile — trigger weapon setup first
        if (!gun && ctx.best_weapon && (ctx.has_ammo_pile || ctx.has_loaded_mag))
        {
            PredAI_WeaponDirector.Execute(ctx, dt);
            gun = ai.eAI_GetAnyWeaponToUse(true, false);
        }

        if (gun)
        {
            //! Put weapon in hands if setting is on
            if (cfg.combat.force_weapon_select)
                PredAI_WeaponDirector.TryPutWeaponInHands(ctx, gun);

            //! Movement speed scaling by range — Expansion AI handles aiming + firing automatically
            if (dist <= cfg.combat.close_range)
                ai.OverrideMovementSpeed(true, 2);   //! run to close gap
            else if (dist <= cfg.combat.mid_range)
                ai.OverrideMovementSpeed(true, 1);   //! jog at mid range
            else
                ai.OverrideMovementSpeed(false, 0);  //! walk/default at long range
        }
        else
        {
            //! No firearm — melee if close, otherwise run away and find a weapon
            if (dist <= cfg.combat.close_range)
            {
                ai.Notify_Melee(true);
                ai.OverrideMovementSpeed(true, 3);
                ctx.AddScore(2, "melee-pressure");
            }
            else
            {
                ai.SetMovementSpeedLimit(3);
                ctx.AddScore(-4, "combat-no-usable-weapon");
                PredAI_WeaponDirector.Execute(ctx, dt);
                PredAI_LootDirector.Execute(ctx, dt);
            }
        }

        //! Flanking / combat repositioning to break stationary camping
        if (ctx.stationary_seconds >= cfg.combat.flank_after_stationary_seconds &&
            ctx.since_combat_reposition >= cfg.combat.combat_reposition_seconds)
        {
            ctx.since_combat_reposition = 0.0;
            vector tpos = target.GetPosition();
            vector flank = PredAI_NavigationDirector.RandomNearby(tpos, cfg.combat.flank_distance);
            ai.OverrideTargetPosition(flank, false, 2.0, true);
            ctx.AddScore(3, "combat-flank-repath");
        }
    }
}
