class PredAI_Brain
{
    static void Tick(PredAI_Context ctx, float dt)
    {
        if (!ctx || !ctx.ai)
            return;

        PredAISettings cfg = PredAI_Config.Get();

        //! Between decisions: keep executing the active goal
        if (ctx.decision_accumulator < cfg.brain_decision_cooldown)
        {
            ExecuteGoal(ctx, cfg, ctx.active_goal, dt);
            return;
        }

        ctx.decision_accumulator = 0.0;
        int goal = ChooseGoal(ctx, cfg);
        ctx.SetGoal(goal, BuildReason(ctx));
        ExecuteGoal(ctx, cfg, goal, dt);
    }

    static int ChooseGoal(PredAI_Context ctx, PredAISettings cfg)
    {
        //! Priority 1: critical health — bandage immediately regardless of anything else
        if (ctx.should_bandage && ctx.has_bandage &&
            (ctx.health <= cfg.medical.health_critical || ctx.blood01 <= cfg.medical.blood_low01))
            return PredAI_GoalType.EMERGENCY_MEDICAL;

        //! Priority 2: has target + brave enough to fight while bleeding → fight anyway
        if (ctx.should_bandage && ctx.has_bandage && ctx.has_target &&
            ctx.personality.WillRiskBleedingFight(ctx.health, ctx.target_distance))
            return PredAI_GoalType.COMBAT;

        //! Priority 3: bandage without pressure
        if (ctx.should_bandage && ctx.has_bandage)
            return PredAI_GoalType.MEDICAL;

        //! Priority 4: bleeding but no bandage — go loot one
        if (ctx.should_bandage && !ctx.has_bandage)
            return PredAI_GoalType.LOOT;

        //! Body camp break (target_is_body is safe-false until eAITarget API is confirmed)
        if (ctx.target_is_body)
        {
            if (ctx.body_camp_seconds >= cfg.combat.anti_body_camp_seconds)
                return PredAI_GoalType.BREAK_BODY_CAMP;

            if (cfg.loot.enabled && ctx.personality.greed > 0.45)
                return PredAI_GoalType.LOOT;
        }

        //! Anti-stuck
        if (ctx.stationary_seconds >= cfg.navigation.stuck_seconds)
            return PredAI_GoalType.REPOSITION;

        //! Weapon setup if not combat-ready
        if (PredAI_WeaponDirector.NeedsWeaponSetup(ctx) &&
            (ctx.has_target || !ctx.has_loaded_weapon || ctx.stationary_seconds > 2.5))
            return PredAI_GoalType.WEAPON_SETUP;

        //! Active, real threat
        if (ctx.has_target && ctx.target_threat >= cfg.combat.min_threat_to_engage)
            return PredAI_GoalType.COMBAT;

        //! Loot if no weapon or greedy
        if (cfg.loot.enabled && (!ctx.has_firearm || (!ctx.has_loaded_weapon && !ctx.has_ammo) ||
            ctx.personality.greed > 0.78))
            return PredAI_GoalType.LOOT;

        //! Idle patrol if standing still too long
        if (ctx.stationary_seconds >= cfg.navigation.idle_repath_seconds)
            return PredAI_GoalType.IDLE_PATROL;

        return PredAI_GoalType.NONE;
    }

    static string BuildReason(PredAI_Context ctx)
    {
        string r = "score=" + ctx.score.ToString();
        if (ctx.should_bandage)        r += " bleeding";
        if (ctx.has_target)            r += " target";
        if (ctx.target_is_body)        r += " body";
        if (!ctx.has_firearm)          r += " no_weapon";
        if (ctx.has_firearm && !ctx.has_loaded_weapon) r += " weapon_needs_ammo";
        if (ctx.has_empty_mag && !ctx.has_loaded_mag && !ctx.has_ammo_pile) r += " empty_mag_only";
        if (ctx.has_loaded_weapon && !ctx.weapon_in_hands) r += " weapon_not_hands";
        if (ctx.stationary_seconds > 3.0) r += " stationary=" + ctx.stationary_seconds.ToString();
        return r;
    }

    static void ExecuteGoal(PredAI_Context ctx, PredAISettings cfg, int goal, float dt)
    {
        switch (goal)
        {
            case PredAI_GoalType.EMERGENCY_MEDICAL:
                PredAI_MedicalDirector.Execute(ctx, true);
                return;
            case PredAI_GoalType.MEDICAL:
                PredAI_MedicalDirector.Execute(ctx, false);
                return;
            case PredAI_GoalType.COMBAT:
                PredAI_CombatDirector.Execute(ctx, dt);
                return;
            case PredAI_GoalType.LOOT:
                PredAI_LootDirector.Execute(ctx, dt);
                return;
            case PredAI_GoalType.REPOSITION:
                PredAI_NavigationDirector.ForceRepath(ctx, "stuck-reposition", cfg.navigation.idle_goal_move_distance);
                return;
            case PredAI_GoalType.BREAK_BODY_CAMP:
                PredAI_NavigationDirector.BreakBodyCamp(ctx);
                return;
            case PredAI_GoalType.IDLE_PATROL:
                PredAI_NavigationDirector.IdlePatrol(ctx);
                return;
            case PredAI_GoalType.WEAPON_SETUP:
                PredAI_WeaponDirector.Execute(ctx, dt);
                return;
        }
    }
}
